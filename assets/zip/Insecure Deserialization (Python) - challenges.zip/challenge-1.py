import pickle


class TestClass:
    def __init__(self, test_value):
        self.test_attribute = test_value

    def __str__(self):
        return "[Test object -> %s]" % self.test_attribute


def my_serialize(obj):
    serialized = pickle.dumps(obj)
    print("[*] Serialized object: %s" % serialized)
    return serialized


def my_deserialize(obj):
    if obj is None:
        print("[*] Nothing to deserialize.")
        return None
    return pickle.loads(obj)


def my_exploit():
    # TODO
    return None


if __name__ == '__main__':
    print("Insecure Deserialization - Challenge 1")

    print("\nLet's create a test object.")
    test_object = TestClass("this is a test")
    print("[*] Object: %s" % test_object)

    print("\nLet's serialize it.")
    serialized_object = my_serialize(test_object)

    print("\nNow let's try to deserialize it to obtain the initial object.")
    deserialized_object = my_deserialize(serialized_object)
    print("[*] Object: %s" % deserialized_object)

    print("\nYou have to read \"flag.txt\" file.")
    print("Can you exploit it? :)")
    exploit_object = my_exploit()
    deserialized_object = my_deserialize(exploit_object)
    print("\n[*] Object: %s" % deserialized_object)

    print()
