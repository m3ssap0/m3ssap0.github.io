import pickle
import pickletools


class TestClass:
    def __init__(self, test_value):
        self.test_attribute = test_value

    def __str__(self):
        return "[Test object -> %s]" % self.test_attribute


def my_serialize(obj):
    serialized = pickle.dumps(obj)
    print("[*] Serialized object: %s" % serialized)
    return serialized


def my_deserialize(obj):
    if obj is None:
        print("[*] Nothing to deserialize.")
        return None
    security_check(obj)  # You shall not pass! Maybe... ^^
    return pickle.loads(obj)


class AttackDetected(Exception):
    pass


def security_check(obj):
    print("[*] Checking the input to prevent attacks.")
    bad_words = ("system", "Popen", "call", "eval", "hread", "proc",
                 "exec", "run", "pexpect", "sh", "plumbum", "fabric", "envoy")
    bad_op_code = "REDUCE"
    attack_detected = False
    for op_code, arg, pos in pickletools.genops(obj):
        print("[*]     op_code.name = '%s', arg = '%s', op_code.pos = '%s'" % (op_code.name, arg, pos))
        if op_code.name in bad_op_code:
            attack_detected = True
            print("[!]        ^... Found malicious content (op_code.name)!")
        if isinstance(arg, bytes):
            arg = str(arg.decode("utf-8"))
        if arg and isinstance(arg, str) and any(bw in arg for bw in bad_words):
            attack_detected = True
            print("[!]        ^... Found malicious content (arg)!")
    if attack_detected:
        raise AttackDetected()
    else:
        print("[*] Input is good.")


def my_exploit():
    # TODO
    return None


if __name__ == '__main__':
    print("Insecure Deserialization - Challenge 2")

    print("\nLet's create a test object.")
    test_object = TestClass("this is a test")
    print("[*] Object: %s" % test_object)

    print("\nLet's serialize it.")
    serialized_object = my_serialize(test_object)

    print("\nNow let's try to deserialize it to obtain the initial object.")
    deserialized_object = my_deserialize(serialized_object)
    print("[*] Object: %s" % deserialized_object)

    print("\nYou have to read \"flag.txt\" file.")
    print("Can you exploit it? :)")
    exploit_object = my_exploit()
    try:
        deserialized_object = my_deserialize(exploit_object)
        print("[*] Object: %s" % deserialized_object)
    except AttackDetected:
        print("[!] Attack detected!")

    print()
