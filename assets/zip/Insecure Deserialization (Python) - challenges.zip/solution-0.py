class User:
    def __init__(self, username, role, fullname):
        self.username = username
        self.role = role
        self.fullname = fullname

    def __str__(self):
        return "[%s username=%s, role=%s, fullname=%s]" % (self.__class__.__name__, self.username, self.role, self.fullname)


def my_serialize(user):
    serialized = "%s|%s|%s|%s" % (user.__class__.__name__, user.username, user.role, user.fullname)
    print("[*] Serialized object: %s" % serialized)
    return serialized


def my_deserialize(user):
    if user is None:
        print("[*] Nothing to deserialize.")
    user_data = user.split("|")
    class_name = user_data[0]
    if class_name == "User":
        return User(user_data[1], user_data[2], user_data[3])
    else:
        print("[*] Unknown object.")


def super_secret_function(username, fullname):
    if username is None or fullname is None \
            or not isinstance(username, str) or not isinstance(fullname, str) \
            or len(username.strip()) < 1 or len(fullname.strip()) < 1:
        print("[!] Access denied!")
    else:
        user = User(username, "user", fullname)
        serialized_user = my_serialize(user)
        deserialized_user = my_deserialize(serialized_user)
        if deserialized_user.role.lower() == "admin":
            with open("flag.txt", "r") as f:
                flag = f.read()
            print("[*] Access granted for '%s'!" % deserialized_user.username)
            print("[*] Hi %s, here is your flag: %s" % (deserialized_user.fullname, flag))
        else:
            print("[!] Access denied!")


def my_exploit():
    return "sam.sepiol|admin|Elliot Alderson", "padding"


if __name__ == '__main__':
    print("Insecure Deserialization - Challenge 0")

    print("\nLet's create a test object.")
    test_object = User("sam.sepiol", "user", "Elliot Alderson")
    print("[*] Object: %s" % test_object)

    print("\nLet's serialize it.")
    serialized_object = my_serialize(test_object)

    print("\nNow let's try to deserialize it to obtain the initial object.")
    deserialized_object = my_deserialize(serialized_object)
    print("[*] Object: %s" % deserialized_object)

    print("\nLet's try to use the \"super_secret_function\".")
    super_secret_function(deserialized_object.username, deserialized_object.fullname)

    print("\nYou have to use the \"super_secret_function\".")
    print("Can you exploit it? :)")
    exploit_username, exploit_fullname = my_exploit()
    super_secret_function(exploit_username, exploit_fullname)

    print()
